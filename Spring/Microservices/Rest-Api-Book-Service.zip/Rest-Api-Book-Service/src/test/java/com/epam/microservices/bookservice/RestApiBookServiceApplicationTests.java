package com.epam.microservices.bookservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiBookServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
