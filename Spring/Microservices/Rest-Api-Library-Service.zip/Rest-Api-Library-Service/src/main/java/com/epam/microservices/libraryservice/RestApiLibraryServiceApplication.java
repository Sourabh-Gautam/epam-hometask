package com.epam.microservices.libraryservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiLibraryServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiLibraryServiceApplication.class, args);
	}

}
