package com.epam.microservices.userservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiUserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
