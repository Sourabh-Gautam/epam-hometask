package com.epam.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

@WebMvcTest(controllers = UserController.class)
public class UserControllerTest {
	
	private

	@Test
	void addUserTest() {
		
	}
	
}
